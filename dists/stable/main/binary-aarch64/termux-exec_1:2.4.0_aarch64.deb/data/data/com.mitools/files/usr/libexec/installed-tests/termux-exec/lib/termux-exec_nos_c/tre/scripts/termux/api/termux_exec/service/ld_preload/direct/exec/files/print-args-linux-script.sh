#!/data/data/com.mitools/files/usr/bin/sh

echo "$@"
